/* import firebase from "firebase/app";
import 'firebase/firestore';

const configuracionFirebase = {
    apiKey: "AIzaSyC9Mtl9jXxM7xCU0NPGDgHmSs6MNQDMghI",
    authDomain: "mercadolibrecopia.firebaseapp.com",
    projectId: "mercadolibrecopia",
    storageBucket: "mercadolibrecopia.appspot.com",
    messagingSenderId: "952451773877",
    appId: "1:952451773877:web:392deb86fea4948a8f95fc",
    measurementId: "G-8VKD3TM10K"
  }

  firebase.initializeApp(configuracionFirebase)
  export default firebase; */